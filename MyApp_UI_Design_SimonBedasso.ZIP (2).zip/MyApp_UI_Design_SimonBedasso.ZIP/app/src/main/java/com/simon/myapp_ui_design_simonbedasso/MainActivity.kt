package com.simon.myapp_ui_design_simonbedasso

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import net.sqlcipher.database.SQLiteDatabase as SecureDB // Secure database
import net.sqlcipher.database.SupportFactory
import java.security.SecureRandom
import java.util.Base64
import org.mindrot.jbcrypt.BCrypt

class MainActivity : AppCompatActivity() {
    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Reference UI elements
        val usernameEditText = findViewById<EditText>(R.id.username)
        val passwordEditText = findViewById<EditText>(R.id.password)
        val loginButton = findViewById<Button>(R.id.login_button)
        val signUpButton = findViewById<Button>(R.id.signup_button)

        // Initialize database helper
        dbHelper = DatabaseHelper(this)

        // Handle Login Button Click
        loginButton.setOnClickListener {
            val username = usernameEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Username and password cannot be empty!", Toast.LENGTH_SHORT).show()
            } else {
                val isValid = dbHelper.checkUserCredentials(username, password)
                if (isValid) {
                    Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this, DataDisplayActivity::class.java))
                } else {
                    Toast.makeText(this, "Invalid credentials!", Toast.LENGTH_SHORT).show()
                }
            }
        }

        // Handle Sign-Up Button Click
        signUpButton.setOnClickListener {
            val username = usernameEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Username and password cannot be empty!", Toast.LENGTH_SHORT).show()
            } else {
                val success = dbHelper.addUser(username, password)
                if (success) {
                    Toast.makeText(this, "Account created successfully!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Failed to create account. Try another username.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
