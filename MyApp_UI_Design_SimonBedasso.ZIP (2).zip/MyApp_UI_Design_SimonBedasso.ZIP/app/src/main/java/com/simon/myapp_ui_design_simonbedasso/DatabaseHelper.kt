package com.simon.myapp_ui_design_simonbedasso

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.mindrot.jbcrypt.BCrypt  // ✅ FIX: Added correct bcrypt import

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        val createUsersTable = """
            CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT, 
                username TEXT UNIQUE, 
                password TEXT
            )
        """.trimIndent()
        db.execSQL(createUsersTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS users")
        onCreate(db)
    }

    // Function to add a new user with hashed password
    fun addUser(username: String, password: String): Boolean {
        val db = writableDatabase
        val values = ContentValues()
        val hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt()) // ✅ FIX: Hashing password before storing

        values.put("username", username)
        values.put("password", hashedPassword)

        return try {
            db.insert("users", null, values) != -1L
        } catch (e: Exception) {
            false // Username already exists or database error
        } finally {
            db.close()
        }
    }

    // Function to check user credentials securely
    fun checkUserCredentials(username: String, password: String): Boolean {
        val db = readableDatabase
        val query = "SELECT password FROM users WHERE username = ?"
        val cursor = db.rawQuery(query, arrayOf(username))

        var isValid = false
        if (cursor.moveToFirst()) {
            val storedHash = cursor.getString(0)
            isValid = BCrypt.checkpw(password, storedHash) // ✅ FIX: Securely verify the password
        }
        cursor.close()
        db.close()
        return isValid
    }

    companion object {
        private const val DATABASE_NAME = "app_database"
        private const val DATABASE_VERSION = 1
    }
}
