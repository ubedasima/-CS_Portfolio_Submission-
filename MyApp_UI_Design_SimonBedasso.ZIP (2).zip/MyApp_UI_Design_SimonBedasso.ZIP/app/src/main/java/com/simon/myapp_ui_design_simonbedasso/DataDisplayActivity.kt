package com.simon.myapp_ui_design_simonbedasso

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class DataDisplayActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_data_display)

        // Reference UI elements
        val recyclerView = findViewById<RecyclerView>(R.id.data_recycler_view)
        val addDataButton = findViewById<Button>(R.id.add_data_button)
        val deleteDataButton = findViewById<Button>(R.id.delete_data_button)

        // Set up RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Initialize an empty dataset (Replace with actual data logic)
        val sampleData = mutableListOf("Item 1", "Item 2", "Item 3")
        val adapter = DataAdapter(sampleData) // Make sure DataAdapter.kt exists
        recyclerView.adapter = adapter

        // Handle Add Data Button Click
        addDataButton.setOnClickListener {
            sampleData.add("New Item ${sampleData.size + 1}")
            adapter.notifyDataSetChanged()
        }

        // Handle Delete Data Button Click (Removes the last item)
        deleteDataButton.setOnClickListener {
            if (sampleData.isNotEmpty()) {
                sampleData.removeAt(sampleData.size - 1)
                adapter.notifyDataSetChanged()
            }
        }
    }
}
